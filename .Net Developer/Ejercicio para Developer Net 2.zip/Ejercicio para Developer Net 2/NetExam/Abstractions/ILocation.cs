﻿namespace NetExam.Abstractions
{
    public interface ILocation
    {
        string Name { get; }
    }
}