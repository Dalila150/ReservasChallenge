﻿namespace NetExam.Abstractions
{
    using System;

    public interface IBooking
    {
        DateTime DateTime { get; }
    }
}